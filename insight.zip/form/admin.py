from django.contrib import admin
from form.model import form_registration
from form.model import Events
from form.model import Contact
from form.model import Category
from form.model import Order_event

class AdminEvents(admin.ModelAdmin):
    list_display = ['event_name' , 'event_price' ,'event_desc', 'Category']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']


class AdminOrder_event(admin.ModelAdmin):

    list_display = ['id','events','s_id','s_name','e_attendance']

    #def get_queryset(self, request):
     #   if request.user.is_superuser:
      #      queryset = Order_event.objects.all()
       # else:
        #    try:
         #        queryset = Order_event.objects.filter(s_coordinator=request.user.id)
          #  except:
           #     queryset = Order_event.objects.none()
        #return queryset


# Register your models here.


admin.site.register(form_registration)
admin.site.register(Events, AdminEvents)
admin.site.register(Contact)
admin.site.register(Category, AdminCategory)
admin.site.register(Order_event , AdminOrder_event)