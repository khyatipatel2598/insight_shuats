from django.apps import AppConfig


class FormConfig(AppConfig):
    name = 'form'
