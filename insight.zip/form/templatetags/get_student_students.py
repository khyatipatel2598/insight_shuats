from django import template

register = template.Library()

@register.filter(name='is_name')
def is_name(students):
    #print(students)
    return students[0]

@register.filter(name='is_email')
def is_name(students):
    s_name=''
    #print(students)
    return students[1]

@register.filter(name='is_contact')
def is_name(students):
    s_name=''
    #print(students)
    return students[2]





