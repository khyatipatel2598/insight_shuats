from django import template

register = template.Library()

@register.filter(name='is_event_name')
def is_name(event):
    #print(students)
    return event[0]

@register.filter(name='is_s_name')
def is_name(event):
    s_name=''
    #print(students)
    return event[1]

@register.filter(name='is_college_id')
def is_name(event):
    s_name=''
    #print(students)
    return event[2]

@register.filter(name='is_email')
def is_name(event):
    s_name=''
    #print(students)
    return event[3]

@register.filter(name='is_contact')
def is_name(event):
    s_name=''
    #print(students)
    return event[4]







