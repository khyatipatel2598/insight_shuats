from django import template

register = template.Library()

@register.filter(name='is_events')
def is_name(events,index):

    print(index,'index')
    print(events[index],'events[index]')
    j=events[index]
    s=''
    if (j==[]):
        print(j,'j')
        print(s,'s')
        s="The student has not participated in any event"
        return (s)
    else :
        for k in j:
            print(k)
            s += k

            s += ' '
            s += ' ,'

        s = s.rstrip(s[-1])
        print(s)
        return (s)



